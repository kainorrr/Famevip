
document.getElementById('bypass-button').addEventListener('click', function() {
    const url = document.getElementById('url-input').value;
    const bypassStatus = document.createElement('div');
    bypassStatus.id = 'bypass-status';
    bypassStatus.innerText = 'Bypassing...';
    document.body.appendChild(bypassStatus);
    bypassStatus.style.display = 'flex';

    setTimeout(() => {
        fetch('https://bypass-api.example.com/bypass?url=' + encodeURIComponent(url))
            .then(response => response.json())
            .then(data => {
                window.location.href = data.bypassed_url;
            })
            .catch(error => {
                bypassStatus.innerText = 'Error: ' + error.message;
            });
    }, 2000);
});
